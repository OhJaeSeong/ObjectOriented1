//
// Created by 김혁진 on 2019/10/28.
//

#ifndef SMART_PTR_HUMAN_H
#define SMART_PTR_HUMAN_H

#include <iostream>
	class human{
	private :
		char* name;
	public :
		human();
		human(char* name);
		char* get_name();
		int get_id();
	};


#endif //SMART_PTR_HUMAN_H
